# AI Decision Network Simulator
Unit V – Uncertain Knowledge and Reasoning (static site: HTML, CSS, JS).

## Deploy on Render
1. Push this folder to a GitHub repo.
2. Render Dashboard -> New -> Static Site -> pick the repo.
3. Build Command: (leave empty)   Publish Directory: .
4. Click Create Static Site. Your live URL appears when the deploy finishes.
